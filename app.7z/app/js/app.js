'use strict';

var app = angular.module('employeeApp', ['ngResource','ngRoute'])
.config(function($routeProvider,$locationProvider){
    $routeProvider.when('/employeeList',{
        templateUrl:'templates/EmployeeList.html',
        controller:'EmployeeRestController',
    });
    $routeProvider.when('/addEmployee',{
        templateUrl:'templates/AddEmployee.html',
        controller:'EmployeeRestController'
    });
    $routeProvider.otherwise({redirectTo:'/employeeList'});
    // $locationProvider.html5Mode(true);
});
