'use strict';
var app = angular.module('employeeApp');
app.controller('EmployeeRestController', function ($scope, empData) {

   // $scope.employee = {};

    $scope.saveEmployee = function (employee) {
        console.log("saving employee " + JSON.stringify(employee));
        empData.saveEmployee(employee);
    };
    $scope.cancelEdit = function () {
        window.location = "Index.html";
    };

    empData.getEmployees(function (employee) {
        $scope.employee = employee;
    });
});


