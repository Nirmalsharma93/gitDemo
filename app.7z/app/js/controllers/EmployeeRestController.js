'use strict';
var app = angular.module('employeeApp');
app.controller('EmployeeRestController', function($scope, empData) {
   
    $scope.employees = [];
    $scope.saveEmployee = function(employee,newEmployeeForm)
    {
        if(newEmployeeForm.$valid){

            empData.saveEmployee(employee);
            //window.alert('employee'+ employee.name +'has been saved');
        }
    };
    $scope.cancelEdit = function()
    {
        window.location="Index.html";
    };
    
    $scope.getEmployees = function(){
        empData.getEmployees();
    };
});