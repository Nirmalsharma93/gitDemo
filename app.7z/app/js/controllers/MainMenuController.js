'use strict';
var app = angular.module('employeeApp');
app.controller('MainMenuController', function MainMenuController($scope, $location) {

    $scope.addEmployee = function(){
        $location.url('/addEmployee');
    };
    $scope.getAllEmployee = function(){
        $location.url('/employeeList');
    };
});