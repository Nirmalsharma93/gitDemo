var app = angular.module('employeeApp');
app.factory('empData', function ($http ,$log) {
    return {
        getEmployees:  function(successcb)
        {
            // $http({method: 'GET', url:'http://localhost:8080/../list'}).
            // success(function(data,status,headers,config)
            // {
            //     successcb(data);
            // }).
            // error(function(data,status,headers,config)
            // {
            //     $log.warn(data,status,headers,config);       
            // }); 
            console.log("get method for Emp data is working ");
        },
        saveEmployee: function(employee){
            // var method = "";
            // var url = "";
            // if ($scope.newEmployeeForm.id == -1) {
            //     method = "POST";
            //     url = '/../addEmployee';
            // } else {
            //     method = "PUT";
            //     url = '/../countries';
            // }
            return $http({
                method : "POST",
                url : '/../addEmployee',
                data : angular.toJson($scope.newEmployeeForm),
                headers : {
                    'Content-Type' : 'application/json'
                }
            })
        }
    }
});