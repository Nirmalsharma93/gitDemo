var app = angular.module('employeeApp');
app.factory('empData', function ($http, $log) {
    return {
        getEmployees: function (successcb) {
            console.log("get method for Emp data is working ");
            $http({ method: 'GET', url: 'http://localhost:8080/spring-rest-hibernate-angular/list' }).
                success(function (data, status, headers, config) {
                    successcb(data);
                }).
                error(function (data, status, headers, config) {
                    $log.warn(data, status, headers, config);
                });

        },
        saveEmployee: function (employee) {
            console.log("Post method for Emp data is working from dataservice "+JSON.stringify(employee));
            return $http.post('http://localhost:8080/spring-rest-hibernate-angular/addEmployee', JSON.stringify(employee)).
                then(function (response) {
                    if (response.employee) {
                        console.log("Post method for Emp data is working "+response.employee);
                    }
                }, function (response) {
                    console.log("Post method for Emp data is not working "+response);
                });
        }
    }
});