'use strict';

var app = angular.module('eventsApp', []);

// to use ng-bind-html we need to add sanitize.js in html file and add dependency in module section
//var app = angular.module('eventsApp', ['ngSanitize']);