var app = angular.module('eventsApp');
//first parameter is service
// don't use $ sign for custom service, you might end up overriding angular inbuilt services
app.factory('eventData', function () {
    return {
        event:
        {
            name: 'Anuglar Boot camp',
            date: '10/06/2019',
            time: '11:25am',
            location: {
                address: 'Atos Syntel office',
                city: 'Pune',
                state: 'MH'
            },
            imageUrl: 'img/angularjs-logo.png',
            sessions: [
                {
                    name: 'Directive class ',
                    creatorName: 'Ankit',
                    level: 'Novice',
                    duration: 1,
                    upVoteCount: 0
                },
                {
                    name: 'PluralSight class Novice',
                    creatorName: 'Pukhraj',
                    level: 'Pro',
                    duration: 2,
                    upVoteCount: 0
                },
                {
                    name: 'Atos syntel class',
                    creatorName: 'Sagar',
                    level: 'Intermediate',
                    duration: 4,
                    upVoteCount: 0
                }
            ]
        }
    };
});