var app = angular.module('employeeApp');
app.factory('empData', function ($http ,$log) {
    return {
        getEmployees:  function(successcb)
        {
            $http({method: 'GET', url:'http://localhost:8080/../list'}).
            success(function(data,status,headers,config)
            {
                successcb(data);
            }).
            error(function(data,status,headers,config)
            {
                $log.warn(data,status,headers,config);       
            }); 
        },
        saveEmployee: function(){
            var method = "";
            var url = "";
            if ($scope.countryForm.id == -1) {
                method = "POST";
                url = '/../addEmployee';
            } else {
                //Id is present in form data, it is edit country operation
                method = "PUT";
                url = '/../countries';
            }
 
            $http({
                method : method,
                url : url,
                data : angular.toJson($scope.newEmployeeForm),
                headers : {
                    'Content-Type' : 'application/json'
                }
            }).then( _success, _error );
        }
    }
});