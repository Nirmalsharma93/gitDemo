'use strict';
var app = angular.module('employeeApp');
app.controller('EmployeeRestController', function($scope, empData) {
   
    $scope.employees = [];
    $scope.saveEmployee = function(employee,newEmployeeForm)
    {
        if(newEmployeeForm.$valid){
            window.alert('employee'+ employee.name +'has been saved');
        }
    };
    $scope.cancelEdit = function()
    {
        window.location="Index.html";
    };
    
    empData.getEmployees(function(employee){
        $scope.employee = employee;
    });
});