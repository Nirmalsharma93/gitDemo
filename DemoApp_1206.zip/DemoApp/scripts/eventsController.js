'use strict';
var fs = require('fs');

console.log('Hello form ');
module.exports.get = function(req,res){
    console.log('Hello form '+req.params.id);
    var event = fs.readFileSync('app/data/event/'+req.params.id+'.JSON','utf8');
    res.setHeader('Content-Type','application/json');
    //res.setHeader('Access-Control-Allow-Origin','*');
    res.send(event);
}


module.exports.save = function(req,res){
    var event = req.body;
    fs.writeFileSync('/app/data/event/'+req.params.id+'.json',JSON.stringify(event));    
    res.send(event);
}