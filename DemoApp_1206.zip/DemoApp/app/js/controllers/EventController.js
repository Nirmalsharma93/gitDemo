'use strict';
var app = angular.module('eventsApp');
app.controller('EventController', function ($scope, eventData, $log) {
    // $scope.snippet = '<span style="color:red">Hi There</span>';
    // $scope.boolValue = false;
    // - helps in doing desc order. its being used with eventDetails.html's filter 
    // $scope.sortOrder = 'name';
    // $scope.event= eventData.event;

    eventData.getEvent()
        .success(function (event) {
            $scope.event = event;
        })
        .error(function (data, status, headers, config) {
            $log.warn(data, status, headers(), config);
        });

    $scope.upVoteSession = function (session) {
        session.upVoteCount++;
    }

    $scope.downVoteSession = function (session) {
        session.upVoteCount--;
    }

});