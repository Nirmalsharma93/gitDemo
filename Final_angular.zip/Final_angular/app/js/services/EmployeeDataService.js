var app = angular.module('employeeApp');
app.factory('empData', function ($http ,$log) {
    return {
        getEmployees:  function(successcb)
        {
            console.log("get method for Emp data is working ");
            $http({method: 'GET', url:'http://localhost:8083/spring-rest-hibernate-angular/list'}).
            success(function(data,status,headers,config)
            {
                successcb(data);
            }).
            error(function(data,status,headers,config)
            {
                $log.warn(data,status,headers,config);       
            }); 
           
        },
        saveEmployee: function(employee){
            console.log("Post method for Emp data is working ");
            var method = "";
            var url = "";
            if ($scope.newEmployeeForm.id == -1) {
                method = "POST";
                url = 'http://localhost:8083/spring-rest-hibernate-angular/addEmployee';
            } else {
                method = "PUT";
                url = 'http://localhost:8083/spring-rest-hibernate-angular/list/{id}';
            }
            return $http({
                method : method,
                url : url,
                data : angular.toJson($scope.newEmployeeForm),
                headers : {
                    'Content-Type' : 'application/json'
                }
            })
        }
    }
});