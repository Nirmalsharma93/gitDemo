'use strict';
var app = angular.module('employeeApp');
app.controller('EmployeeRestController', function ($scope, empData) {

    $scope.employees = [];
    
    $scope.saveEmployee = function (employee, newEmployeeForm) {
        if (newEmployeeForm.$valid) {
            empData.saveEmployee(employee)
                .$promises.then(function (response) { console.log('success', response) }
                    .catch(function (response) { console.log('failure', response) }));
            //window.alert('employee'+ employee.name +'has been saved');
        }
    };
    $scope.cancelEdit = function () {
        window.location = "Index.html";
    };

    empData.getEmployees(function (employee) {
        $scope.employee = employee;
    });
});