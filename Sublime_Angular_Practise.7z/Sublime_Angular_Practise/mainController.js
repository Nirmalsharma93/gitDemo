'use strict';
var app = angular.module('empApp');

app.controller('MainMenuController', function MainMenuController($scope, $location) {

    $scope.addEmployee = function(){
        $location.url('/addEmployee');
    };
    $scope.getAllEmployee = function(){
        $location.url('/list');
    };
    // $scope.editEmployee = function(){
    //     $location.url('/editEmployee');
    // };
});