'use strict';

var app = angular.module('empApp',['ngRoute']);

app.controller('empController',['$scope','empFactory','$route','$window',empController]);

function empController($scope, empFactory,$route,$window){

	$scope.cancelEdit = function () {
		window.location = "index.htm";
	};

	empFactory.getEmployees(function(r){
		$scope.employees = r;
	});	

	$scope.saveEmployee = function (employee) {
		console.log("EmployeeController saving employee " + JSON.stringify(employee));
		empFactory.addEmployee(employee);
		$window.alert("Employee has been saved");
		$window.location.reload();
	};

	$scope.updateEmployee = function (employee){
		console.log("EmployeeController deleteEmployee " + id);
		empFactory.updateEmployee(employee);
		$window.alert("Employee has been added");
		$window.location.reload();
		
	};	
	$scope.deleteEmployee = function (id){
		console.log("EmployeeController deleteEmployee " + id);
		empFactory.deleteEmployee(id);
		$window.alert("Employee has been deleted");
		$window.location.reload();
		
	};	

};



app.directive('empDetails', function(){
	return{
		restrict: 'EAC',
		templateUrl: 'emp-details.htm'
	}
});

app.config(function($routeProvider) {
	$routeProvider
	.when('/index', {
		templateUrl: 'emp-details.htm',
		//template: <div empDetails> </div>
		controller: 'empController'
	})
	.when('/addEmployee', {
		templateUrl: 'add-employee.htm',
		controller: 'empController'
	})
	.when('/editEmployee/:id', {
		templateUrl: 'update-emp.htm',
		controller: 'empController'
	})
	// .when('/list/:id', {
	// 	templateUrl: 'emp-view.htm',
	// 	controller: 'empController'
	// })
	// .when('/deleteEmployee/:id', {
	// 	template: 'emp-details.htm',
	// 	controller: 'empController',

	// })
	.otherwise({
		redirectTo: '/index'
	});
});
