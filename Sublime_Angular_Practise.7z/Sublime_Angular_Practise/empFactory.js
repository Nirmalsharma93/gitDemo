var app = angular.module('empApp');

app.factory('empFactory',['$http','$log','$q',empFactory]);

function empFactory($http,$log,$q)
{
	$log.log("Initializing empFactory");

	var oEmp={};
	oEmp.getEmployees = function(cb){
		$http({
			url:'http://localhost:8080/spring-rest-hibernate-angular/list',
			method:'GET'
		}).then(function(response){
			cb(response.data)
		}).catch(function(response){
			($log.warn("Error Occured in factory"))
		});
	}

	oEmp.getEmployeeById =  function (id) {
		console.log("calling getEmployeeById dataService ");
		return $http({
			method: 'GET',
			url: 'http://localhost:8080/spring-rest-hibernate-angular/list/'+ id
		}).then(function(response){
			cb(response.data)
		}).catch(function(response){
			($log.warn("Error Occured in factory"))
		});
	}

	oEmp.addEmployee = function(employee){
		$http({
			url:'http://localhost:8080/spring-rest-hibernate-angular/addEmployee',
			method:'POST',
			data: employee
		}).then(_addSuccess)
		.catch(_addError)
	}

	oEmp.updateEmployee = function(employee) {
		return $http({
			method: 'PUT',
			url: 'http://localhost:8080/spring-rest-hibernate-angular/list/' + employee.id,
			data: employee
		})
		.then(_updateSuccess)
		.catch(_updateError)
	}

	oEmp.deleteEmployee = function (id) {
		console.log("calling DeleteEmployee");
		return $http({
			method: 'DELETE',
			url: 'http://localhost:8080/spring-rest-hibernate-angular/list/'+ id
		})
		.then(_deleteSuccess)
		.catch(_deleteError)
	}
	function _updateSuccess(response) {
		console.log("calling updateEmployee dataService _updateSuccess");
		return 'Employee updated ' + response.config.employee.firstName;
	}
	function _updateError(response) {
		return $q.reject('Error updating employee. (HTTP status: ' + response.status + ')');
	}

	function _deleteSuccess(response) {
		console.log("calling deleteEmployee dataService _updateSuccess");
		return response.data;
	}
	function _deleteError(response) {
		return $q.reject('Error delete employee. (HTTP status: ' + response.status + ')');
	}

	function _addSuccess(response) {
		console.log("calling addEmployee dataService _addSuccess");
		return response.data;
	}

	function _addError(response) {
		return $q.reject('Error add employee. (HTTP status: ' + response.status + ')');
	}

	return oEmp;
};