(function () {

    angular.module('employeeApp')
        .factory('EmpResource', ['$resource', EmpResource]);

    function EmpResource($resource) {

        return $resource('http://localhost:8080/spring-rest-hibernate-angular/list/:id', {id: '@id'},
            {
                'update': {method: 'PUT'}
            }
        );
    }

}());