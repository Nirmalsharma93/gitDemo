'use strict';
var app = angular.module('employeeApp');
app.controller('EmployeeRestController', ['$scope', 'empData', 'EmpResource', EmployeeRestController]);


function EmployeeRestController($scope, empData, EmpResource) {
    var vm = this;
    vm.allEmployee = [];
    vm.allEmployee = EmpResource.query();


    $scope.saveEmployee = function (employee) {
        console.log("EmployeeRestController saving employee " + JSON.stringify(employee));
        empData.saveEmployee(employee);
    };
    $scope.cancelEdit = function () {
        window.location = "Index.html";
    };

    // empData.getEmployees(function (employee) {
    //     $scope.employee = employee;
    // });

    empData.getEmployees()
        .then(getEmployeeSuccess)
        .catch(errorCallBack);

    function getEmployeeSuccess(employee) {
        console.log("calling EmployeeRestController getEmployeeSuccess " + employee);
        vm.allEmployee = employee;
        //  console.log("calling EmployeeRestController controller "+ vm.allEmployee);
    }
    function errorCallBack(errorMsg) {
        console.log('EmployeeRestController Error: ' + errorMsg);
    }
};


