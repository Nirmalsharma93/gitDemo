'use strict';
var app = angular.module('employeeApp');
app.controller('editEmployeeController', ['$scope', '$routeParams', 'empData','$location','employee', editEmployeeController]);

function editEmployeeController($scope, $routeParams, empData,$location,employee) {
    var vm = this;
    //  console.log("inside editEmployeeController -->"+$routeParams.id + "type "+typeof(employeeslist));
    // vm.currentEmployee = employeeslist.filter(function (item) {
    //     return item.id = $routeParams.id;
    // })[0];
    // empData.getEmployeeById($routeParams.id)
    //     .then(getEmployeeSuccess)
    //     .catch(errorCallBack);

    // function getEmployeeSuccess(employee) {
    //     vm.currentEmployee = employee;
    //     console.log("calling EditEmployeecontroller getEmployeeSuccess callback vm: " +  employee);
    // }
    function errorCallBack(errorMsg) {
        console.log('Error: ' + errorMsg);
    }
    $scope.cancelEdit = function () {
        window.location = "Index.html";
    };

    empData.editEmployee(employee)
    .then(updateEmployeeSuccess)
    .catch(errorCallBack);

    function updateEmployeeSuccess(message) {
        console.log("calling EditEmployeecontroller updateEmployeeSuccess callback "+message);
        $location.path('/');
    }

};

