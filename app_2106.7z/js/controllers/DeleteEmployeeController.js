'use strict';
var app = angular.module('employeeApp');
app.controller('DeleteEmployeeController', ['empData', 'employee', '$route', DeleteEmployeeController]);

function DeleteEmployeeController(empData, employee, $route) {
    var vm = this;
    // vm.allEmployee = [];
    // vm.emps = new EmpResource();
    // vm.allEmployee = EmpResource.query();
    console.log("value in delete controller" + JSON.stringify(employee));
    vm.deleteEmployee = function (id) {
        empData.deleteEmployee(id)
            .then(deleteSuccess)
            .catch(errorCallBack);

    };

    function deleteSuccess() {
        console.log("calling DeleteEmployeeController deleteSuccess callback");
        $route.reload();
    }

    function errorCallBack(errorMsg) {
        console.log('Error: ' + errorMsg);
    }

};

