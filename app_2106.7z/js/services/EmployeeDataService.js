var app = angular.module('employeeApp');
app.factory('empData', function ($http, $log, $routeParams, $q) {
    return {

        getEmployees: getEmployees,
        getEmployeeById: getEmployeeById,
        editEmployee: editEmployee,
        deleteEmployee: deleteEmployee,

        saveEmployee: function (employee) {
            console.log("Post method for EmpDataService is working from dataservice " + JSON.stringify(employee));
            return $http.post('http://localhost:8080/spring-rest-hibernate-angular/addEmployee', JSON.stringify(employee)).
                then(function (response) {
                    if (response.employee) {
                        console.log("Post method for EmpDataService is working " + response.employee);
                        alert("Your data has been saved");
                    }
                }, function (response) {
                    console.log("Post method for EmpDataService is not working " + response);
                });
        },

    }
    function getEmployees() {
        console.log("calling getEmployee dataService");
        return $http({
            method: 'GET',
            url: 'http://localhost:8080/spring-rest-hibernate-angular/list'
        })
            .then(_success)
            .catch(_error)
    }

    function getEmployeeById(id) {
        console.log("calling getEmployeeById dataService ");
        return $http({
            method: 'GET',
            url: 'http://localhost:8080/spring-rest-hibernate-angular/list/'+ id
        })
            .then(_success)
            .catch(_error)
    }

    function editEmployee(employee) {
        return $http({
            method: 'PUT',
            url: 'http://localhost:8080/spring-rest-hibernate-angular/list/' + employee.id,
            data: employee
        })
            .then(_updateSuccess)
            .catch(_updateError)
    }

    function deleteEmployee(id) {
        console.log("calling deleteEmployee dataService");
        return $http({
            method: 'DELETE',
            url: 'http://localhost:8080/spring-rest-hibernate-angular/list/'+ id
        })
            .then(_deleteSuccess)
            .catch(_deleteError)
    }

    function _success(response) {
        console.log("calling getEmployee dataService _Success");
        return JSON.stringify(response.data);
    }
    function _error(response) {
        return $q.reject('Error message: ' + response.status);
    }

    function _updateSuccess(response) {
        console.log("calling updateEmployee dataService _updateSuccess");
        return 'Employee updated ' + response.config.employee.firstName;
    }
    function _updateError(response) {
        return $q.reject('Error updating employee. (HTTP status: ' + response.status + ')');
    }

    function _deleteSuccess(response) {
        console.log("calling deleteEmployee dataService _updateSuccess");
        return 'Employee deleted';
    }
    function _deleteError(response) {
        return $q.reject('Error delete employee. (HTTP status: ' + response.status + ')');
    }

    // getEmployees: function (successcb) {
    //     console.log("get method for EmpDataService is working ");
    //     $http({ method: 'GET', url: 'http://localhost:8080/spring-rest-hibernate-angular/list'}).
    //         success(function (data, status, headers, config) {
    //             successcb(data);
    //         }).
    //         error(function (data, status, headers, config) {
    //             $log.warn(data, status, headers, config);
    //         });

    // },
    // editEmployee : function(employee)
    // {
    //     console.log("Put method for EmpDataService is working from dataservice ");
    //     return $http.put('http://localhost:8080/spring-rest-hibernate-angular/list/'+$routeParams.id, JSON.stringify(employee))
    //         .then(_success)
    //         .catch(_error)
    // },
    // getEmp: function (successcb) {
    //     console.log("Single Emp fetch call dataservice "+$routeParams.id);
    //     $http({ method: 'GET', url: 'http://localhost:8080/spring-rest-hibernate-angular/list/'+$routeParams.id}).
    //         success(function (data) {
    //             successcb(data);
    //         }).
    //         error(function (data, status, headers, config) {
    //             $log.warn(data, status, headers, config);
    //         });

    // },
    // getEmp: function(successcb) {
    //     console.log("Put method for EmpDataService is started--> "+ $routeParams.id);
    //     $http({ method: 'GET', url: 'http://localhost:8080/spring-rest-hibernate-angular/list/'+$routeParams.id})
    //     .then(successcb, _error)
    // }
});