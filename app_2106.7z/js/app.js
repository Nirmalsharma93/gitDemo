'use strict';

var app = angular.module('employeeApp', ['ngResource', 'ngRoute'])
    .config(function ($routeProvider) {
        $routeProvider.when('/employeeList', {
            templateUrl: 'templates/EmployeeList.html',
            controller: 'EmployeeRestController',
            controllerAs: 'empCtrl'
        })
        .when('/addEmployee', {
            templateUrl: 'templates/AddEmployee.html',
            controller: 'EmployeeRestController'
        })
        .when('/editEmployee/:id', {
            templateUrl: 'templates/EditEmployee.html',
            controller: 'editEmployeeController',
            controllerAs: 'empEditor'
        })
        .when('/deleteEmployee/:id', {
            template: 'Data has been deleted',
            controller: 'DeleteEmployeeController',
            controllerAs: 'deleteEmp'
        });
        $routeProvider.otherwise({ redirectTo: '/' });
        // $locationProvider.html5Mode(true);
    });
