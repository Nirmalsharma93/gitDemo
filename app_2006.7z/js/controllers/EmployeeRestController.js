'use strict';
var app = angular.module('employeeApp');
app.controller('EmployeeRestController', ['$scope','empData','EmpResource', EmployeeRestController]);


function EmployeeRestController($scope,empData,EmpResource) {
    var vm = this;
    vm.allEmployee = EmpResource.query();
    // $scope.employee = {};

    $scope.saveEmployee = function (employee) {
        console.log("saving employee " + JSON.stringify(employee));
        empData.saveEmployee(employee);
    };
    $scope.cancelEdit = function () {
        window.location = "Index.html";
    };

    // empData.getEmployees(function (employee) {
    //     $scope.employee = employee;
    // });

    empData.getEmployees()
        .then(getEmployeeSuccess)
        .catch(errorCallBack);

    function getEmployeeSuccess(employee) {
        console.log("calling getEmployee controller "+employee);
        vm.allEmployee = employee;
    }
    function errorCallBack(errorMsg) {
        console.log('Error: ' + errorMsg);
    }
};


