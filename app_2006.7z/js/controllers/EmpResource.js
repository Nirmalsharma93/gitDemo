(function () {

    angular.module('employeeApp')
        .factory('EmpResource', ['$resource', EmpResource]);

    function EmpResource($resource) {

        return $resource('editEmployee/:id', {id: '@id'},
            {
                'update': {method: 'PUT'}
            }
        );
    }

}());