'use strict';
var app = angular.module('employeeApp');
app.controller('editEmployeeController', ['$scope', '$routeParams', 'employeeslist','empData', editEmployeeController]);

function editEmployeeController($routeParams, employeeslist) {
     var vm = this;
    //  console.log("inside editEmployeeController -->"+$routeParams.id + "type "+typeof(employeeslist));
    // vm.currentEmployee = employeeslist.filter(function (item) {
    //     return item.id = $routeParams.id;
    // })[0];
    empData.getEmployeeById($routeParams.id)
    .then(getEmployeeSuccess)
    .catch(errorCallBack);

    function getEmployeeSuccess(employee) {
        console.log("calling Edit Employee controller "+employee);
        vm.currentEmployee = employee;
    }
    function errorCallBack(errorMsg) {
        console.log('Error: ' + errorMsg);
    }

};

