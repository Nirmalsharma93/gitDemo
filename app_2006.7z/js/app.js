'use strict';

var app = angular.module('employeeApp', ['ngResource', 'ngRoute'])
    .config(function ($routeProvider) {
        $routeProvider.when('/employeeList', {
            templateUrl: 'templates/EmployeeList.html',
            controller: 'EmployeeRestController',
        }).when('/addEmployee', {
            templateUrl: 'templates/AddEmployee.html',
            controller: 'EmployeeRestController'
        }).when('/editEmployee/:id', {
            templateUrl: 'templates/EditEmployee.html',
            controller: 'editEmployeeController',
            controllerAs: 'empEditor',
            resolve: {
                employeeslist: function (empData) {
                    return empData.getEmployees;
                }
                // empl : function(empData) {
                //     console.log("got the resolve param");
                //     return empData.getEmp();
                // }

            }
        });
        $routeProvider.otherwise({ redirectTo: '/' });
        // $locationProvider.html5Mode(true);
    });
